setwd("C:\\Users\\ddhan\\OneDrive\\Desktop\\IT24101385-PS-Lab09")

x<-c(3, 7, 11, 0, 7, 0, 4, 5, 6, 2)
t.test(x, mu = 3)

#1
set.seed(123)                    # for reproducibility; change or remove as you like
n <- 25
true_mean <- 45
true_sd <- 2
sample_times <- rnorm(n, mean = true_mean, sd = true_sd)

print("sample (baking times):")
print(round(sample_times, 3))

sample_mean <- mean(sample_times)
sample_sd <- sd(sample_times)
se_sample <- sample_sd / sqrt(n)

cat("sample mean = ",round(sample_mean,4))
cat("sample sd = ", round(sample_sd,4))
cat("se (s/sqrt(n)) = ",round(se_sample,4))

#2
t_test_result <- t.test(sample_times, alternative = "less", mu=46, conf.level = 0.95)
print(t_test_result)

mu <- 46
sigma_pop <- 2
z_stat <- (sample_mean - mu)/(sigma_pop / sqrt(n))
p_value_z <- pnorm(z_stat)

cat("Z-test ")
cat("Z-statistic =",round(z_stat,5))
cat("one-side p-value = ",round(p_value_z,6))

alpha <- 0.05
cat("decision rules")
cat("for t_test: reject H0 if p_value(from t.test) <",alpha)
cat("For z-test: reject H0 if p-value (z) < ", alpha)
